const ctc=document.querySelector('.ctc-text');
const hra=document.querySelector('.hra-text');
const g=document.querySelector('.g-text');
const nps=document.querySelector('.nps-text');
const basic=document.querySelector('.bs-text');
const btn=document.querySelector('.calc-btn');
const opt=document.querySelector('.option');
const pf=document.querySelector('.pf-text');
const net=document.querySelector('.net');
const take=document.querySelector('.take');

ctc.addEventListener("change",function(){

    basic.value=0.4*ctc.value;
    hra.value=0.4*basic.value;
    g.value=0.0481*basic.value;
    nps.value=0.1*basic.value

    if(opt.value =="Low"){
        pf.value=0.05*basic.value

    }
    else{
        pf.value=0.1*basic.value
    }
})

btn.addEventListener('click',function(){
    var temp=ctc.value-(+hra.value+ +nps.value+ +pf.value+ +g.value); //here unaray opertor convert string into integer
    console.log(temp);
    net.innerHTML="Your Net Salary:"+ctc.value;
    take.innerHTML="Your Take Home Salary:"+temp;
})
